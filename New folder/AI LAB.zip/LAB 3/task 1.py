num = 1500
while (num <= 2700):
    if(num%7==0):
        print(num)
    num=num+5