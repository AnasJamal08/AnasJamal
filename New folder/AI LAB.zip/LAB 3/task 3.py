import random
t_num=random.randint(1,10)
num=int(input("Enter Number : "))
while(num!=t_num):
    num=int(input("Enter Number : "))
print("Well guessed!")