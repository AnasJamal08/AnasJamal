import random
def make_matrix(array):
    matrix=[[0,0,0,0],[0,0,0,0],[0,0,0,0],[0,0,0,0]]
    for i in range (0,4):
        matrix[array[i]][i]=1
    return matrix

def right_downward(mtr,x,y):
    attack=0
    while x!=3 and y!=3:
        x+=1
        y+=1
        if mtr[x][y]==1:
            attack+=1
    return attack

def right_upward(mtr,x,y):
    attack=0
    while x!=0 and y!=3:
        x-=1
        y+=1
        if mtr[x][y]==1:                      
            attack+=1
    return attack

def row(mtr,x,y):
    attack=0
    for i in range(y+1,4):
        if mtr[x][i]==1:
            attack+=1
    return attack

def non_attacking(arr):
    total_attacks=0
    for i in range (0,4):
        total_attacks+=right_upward(make_matrix(arr),arr[i],i)
        total_attacks+=right_downward(make_matrix(arr),arr[i],i)
        total_attacks+=row(make_matrix(arr),arr[i],i)
    return(6-total_attacks)

def probabilities(chromo):
    total=0
    for i in range (0,4):
        total+=non_attacking(chromo[i])
    p=[non_attacking(chromo[0])/total * 100,non_attacking(chromo[1])/total * 100,non_attacking(chromo[2])/total * 100,non_attacking(chromo[3])/total * 100]
    return p
#chromosomes=[[1, 3, 0, 1],[3, 1, 3, 0],[0, 2, 1, 2],[3, 0, 1, 0]]
chromosomes=[[1, 0, 2, 1],[3, 1, 3, 0],[0, 2, 1, 2],[3, 0, 1, 0]]
iterations=0

def n_queens():
    global chromosomes
    global iterations
    p=probabilities(chromosomes)
    if (non_attacking(chromosomes[0]) == 6) or (non_attacking(chromosomes[1]) == 6) or (non_attacking(chromosomes[2]) == 6) or (non_attacking(chromosomes[3])) == 6:
        print("Found")
        return
    list = [[p[0],chromosomes[0]], [p[1],chromosomes[1]], [p[2], chromosomes[2]], [p[3], chromosomes[3]]]
    list.sort(reverse=True)

    for i in range(0,4):
        if i>1:
            list[0][1][i-2]=list[1][1][i]
        else:
            list[1][1][i]=list[0][1][i+2]

    for i in range(0,4):
        temp=list[2][1][i]
        if i>2:
            list[2][1][i]=list[3][1][i]
            list[3][1][i]= temp
 
    chromosomes[0]=list[0][1]
    chromosomes[1]=list[1][1]
    chromosomes[2]=list[2][1]
    chromosomes[3]=list[3][1]

    point = random.randint(0, 3)
    chromosomes[0][point]=(chromosomes[0][point]+1)%4
    point = random.randint(0, 3)
    chromosomes[1][point]=(chromosomes[1][point]+1)%4
    point = random.randint(0, 3)
    chromosomes[2][point]=(chromosomes[2][point]+1)%4
    point = random.randint(0, 3)
    chromosomes[3][point]=(chromosomes[3][point]+1)%4
    iterations+=1
    if(iterations<900):
        n_queens()
    else:
        return

n_queens()

print(f"No. of Iterations: {iterations}")