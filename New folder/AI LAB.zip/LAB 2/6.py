import os
os.system("cls")

def my_function(x): 
    return 5 * x 
 
a=my_function(3)
print(a)
print(my_function(5))
print(my_function(9)) 
