rnum = int(input("Enter Rows: "))
cnum = int(input("Enter Columns: "))
arr=[[0]*cnum]*rnum
#for r in range(rnum):
 #   for c in range(cnum):
  #      arr[r][c]= r*c
   #     print(arr[r][c])
print(arr)