num=input()
for i in range(0,int(num)+1):
    for j in range (0,i):
        print("*")
    print("\n")