import random
board1 = [1, 0, 2, 1]
board2 = [3, 1, 3, 0]
board3 = [0, 2, 1, 2]
board4 = [3, 0, 1, 0]

iteration=0
def nonAttackingPair(board):
    list = []
    for i in range(0, 4):
        list.append([board[i], i])

    count = 0
    while (list):
        i, j = list.pop(0)
        if (j < 3):
            for x in range(j+1, 4):
                if [i, x] in list:
                    count += 1
        i1, j1 = i, j
        while (i1 <= 3 and j1 <= 3):
            i1 += 1
            j1 += 1
            if [i1, j1] in list:
                count += 1
        i1, j1 = i, j
        while (i1 >= 0 and j1 <= 3):
            i1 -= 1
            j1 += 1
            if [i1, j1] in list:
                count += 1
    return (6 - count)


def game():
    global board1, board2, board3, board4,iteration
    na1 = nonAttackingPair(board1)
    na2 = nonAttackingPair(board2)
    na3 = nonAttackingPair(board3)
    na4 = nonAttackingPair(board4)

    if na1 == 6 or na2 == 6 or na3 == 6 or na4 == 6:
        print("Congratulations")
        return

    sumNonAttacking = na1 + na2 + na3 + na4
    p1 = na1/sumNonAttacking * 100
    p2 = na2/sumNonAttacking * 100
    p3 = na3/sumNonAttacking * 100
    p4 = na4/sumNonAttacking * 100
    list = [[p1, board1], [p2, board2], [p3, board3], [p4, board4]]
    list.sort(reverse=True)
    pair1 = list[:2]
    pair2 = list[2:4]
    point = random.randint(0, 3)
    pair1.append(pair1[0][1][:point+1] + pair1[1][1][point+1:4])
    pair1.append(pair1[1][1][:point+1] + pair1[0][1][point+1:4])
    point = random.randint(0, 3) 
    pair2.append(pair2[0][1][:point+1] + pair2[1][1][point+1:4])
    pair2.append(pair2[1][1][:point+1] + pair2[0][1][point+1:4])
    del pair1[:2]
    del pair2[:2]
    board1, board2 = pair1
    board3, board4 = pair2
    board1[0] = 3
    board2[1] = 2
    board3[2] = 1
    board4[3] = 4
    iteration+=1
    game()

print(f"No. of Iterations: {iteration}")
game()