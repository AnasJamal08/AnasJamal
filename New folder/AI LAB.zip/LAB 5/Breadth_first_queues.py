graph = {
  'A' : ['B','C'],
  'B' : ['D','F','E'],
  'C' : ['F'],
  'D' : [],
  'E' : ['F'],
  'F' : []
}

visited = set()
queue=[]

def bfs(visited, graph, node):
  visited.add(node)
  queue.append(node)
  while queue:
      m=queue.pop(0)
      print(m," ")
      for neigbour in graph[m]:
        if neigbour not in visited:
          visited.add(neigbour)
          queue.append(neigbour)
    
print("Following is the Breath-First Search")    
bfs(visited, graph, 'A')