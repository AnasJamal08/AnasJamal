import os
os.system("cls")

a=13
print(f"given number is = {a}")