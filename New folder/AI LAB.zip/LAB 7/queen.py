a=[3,2,0,2]
def is_attacked(x1,y1,x2,y2):
    if x1==x2 or y1==y2:
        return True    
    else:
        for i in reversed(range(x1,4)):
            for j in range(y1,4):
                if a[(j+1)%4]==i:
                    return True
        for i in range(x1,4):
            for j in range(y1,4):
                if a[(j+1)%4]==i:
                    return True
        return False

if(is_attacked(3,0,2,3)):
    print("OK")
else:
    print("NOT OK")