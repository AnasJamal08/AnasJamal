x=0
y=1
while y<50:
    print(y)
    n=x
    x=y
    y=n+y