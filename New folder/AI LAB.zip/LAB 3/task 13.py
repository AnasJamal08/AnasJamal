str=input("Enter String : ")
letter=0
digit=0
for i in str:
    if i.isalpha():
        letter=letter+1
    elif i.isdigit():
        digit=digit+1
    else:
        continue
print(f"Letters : {letter}")
print(f"Digits : {digit}")