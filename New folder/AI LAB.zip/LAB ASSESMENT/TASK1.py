from queue import PriorityQueue

graph = {
  'S' : [[3,'A'],[2,'D']],
  'A' : [[10,'C'],[5,'B']],
  'B' : [[2,'C'],[1,'E']],
  'C' : [[4,'G']],
  'D' : [[1,'B'],[4,'E']],
  'E' : [[3,'G']],
  'G' : []
}

huristics={
  'S' : 7,
  'A' : 9,
  'B' : 4,
  'C' : 2,
  'D' : 5,
  'E' : 3,
  'G' : 0
}

def ASTAR(graph, start, goal):
    visited = set()
    queue = PriorityQueue()
    queue.put((0, start))

    while queue:
        cost, node = queue.get()
        print(node)
        if node not in visited:
            visited.add(node)

            if node == goal:
                return
            for i in graph[node]:
                if i[1] not in visited:
                    pathcost = cost + i[0] - huristics[node]
                    total_cost=pathcost+huristics[i[1]]
                    queue.put((total_cost, i[1]))

print("Following is A* Algorithm")
ASTAR(graph,'S','G')