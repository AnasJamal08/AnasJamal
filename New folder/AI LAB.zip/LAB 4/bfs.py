graph = {
  'A' : [[10,'B'],[8,'C']],
  'B' : [[4,'D'], [3,'F'],[2,'E']],
  'C' : [[5,'F']],
  'D' : [],
  'E' : [[3,'F']],
  'F' : []
}

visited = set() 
found=False
mygoal='B' 
def bfs(visited, graph, node,goal):
   
    global found
    
    if node==goal:
        print("Goal Found : ", mygoal)
        found=True 
        return 
    
    elif node not in visited:
        print (node)
        visited.add(node)
        templist=graph[node]
        templist.sort()
        for neighbour in templist:
            #if found==False:
            bfs(visited, graph, neighbour[1],mygoal)

# Driver Code
print("Following is the Best-First Search")
bfs(visited, graph, 'A',mygoal)