graph = {
  'A' : ['B','C'],
  'B' : ['D','E'],
  'C' : ['F','G'],
  'D' : ['H','I'],
  'E' : ['J','K'],
  'F' : ['L','M'],
  'G' : ['N','O'],
  'H' : 3,
  'I' : 5,
  'J' : 2,
  'K' : 7,
  'L' : 3,
  'M' : 9,
  'N' : 1,
  'O' : 4
}


def minimax(graph,node,status):
    if (type(graph[node])==type(1)):
        return graph[node]
    max=0
    min=1000
    if status==1:
        for i in graph[node]:
            var=minimax(graph,i,0)
            if var > max:
                max=var
        return max
    else:
        for i in graph[node]:
            var=minimax(graph,i,1)
            if var < min:
                min=var
        return min

optimal=minimax(graph,'A',1)
print(f"Optimal Solution Value : {optimal}")