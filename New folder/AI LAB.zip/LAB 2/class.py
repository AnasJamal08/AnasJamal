import os
os.system("cls")

class Person: 
    
     def __init__(self, name, age):
         self.name = name 
         self.age = age 
 
     def myfunc(self): 
            print("Hello my name is " + self.name) 

p1=Person("John", 36)
p1.myfunc()

# class Sample: 
#     def __init__(slf, name):
#         slf.name = name

# obj = Sample("Harry") 
# print(obj.name) 
 