num=[]
for num in range(0,6):
    if(num==3 or num==6):
        continue
    print(num)