import os
os.system("cls")

# Python program to illustrate 
# Iterating over a list print("List Iteration")
l = ["geeks", "for", "geeks"] 
for i in l: 
    print(i) 
#----------------------------------------------------
# Iterating over a tuple (immutable) print("\nTuple Iteration") 
t = ("geeks", "for", "geeks") 
for i in t: 
    print(i) 
#----------------------------------------------------
# Iterating over a String print("\nString Iteration") 
s = "Geeks"
for i in s :
    print(i)

