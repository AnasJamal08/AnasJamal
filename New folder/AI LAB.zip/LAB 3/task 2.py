print("What do you want to convert?")
print("1. Celcius to Farenhite.")
print("2. Farenhite to Celcius.")
choice=input("Enter Choice : ")
if (choice=="1"):
    c=input("Enter Temperatue in Celcius : ")
    f=(9/5*int(c))+32
    print(f"Farenhite : {f}")
elif (choice=="2"):
    f=input("Enter Temperatue in Farenhite : ")
    c=(int(f)-32)*5/9
    print(f"Celcius : {c}")
else:
    print("Invalid!!")