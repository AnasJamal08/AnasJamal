ar=0
p1=[[0,0],[1,2],[2,3],[3,1],[4,2]]
def isattack_row(x1,y1,x2,y2):
    global ar
    if y1==y2:
        ar=ar+1
def isattack_left_right_downward(x1,y1,x2,y2):
    global ar
    x1=x1+1        
    y1=y1+1
    if x1==x2 and y1==y2:
        ar=ar+1
def isattack_right_left_upward(x1,y1,x2,y2):
    global ar
    x1=x1-1        
    y1=y1+1
    if x2==x1 and y2==y1:
        ar=ar+1
def isattack_right_left_downward(x1,y1,x2,y2):
    global ar
    x1=x1+1        
    y1=y1-1
    if x2==x1 and y2==y1:
        ar=ar+1
for i in range(0,5):
    x1,y1=p1[i]
    for j in range(i+1,5):
        x2,y2=p1[j]
        isattack_row(x1,y1,x2,y2)
        isattack_left_right_downward(x1,y1,x2,y2)
        isattack_right_left_upward(x1,y1,x2,y2)
        isattack_right_left_downward(x1,y1,x2,y2)
        

ar=6-ar
print(ar)