from collections import OrderedDict

graph = {
  'A' : {'B':'5','C':'4'},
  'B' : {'E':'4','D':'1'},
  'C' : {},
  'D' : {'F':'2','B':'1'},
  'E' : {'C':'7'},
  'F' : {}
}

for i in graph:
    var2=sorted(graph[i].items(),key=lambda item: item[1])
    print(var2)

#print(graph)

#VAR=(graph['A'])
#VAR1=VAR[0].copy()
#num=VAR[0]['B']
#print(type(num))