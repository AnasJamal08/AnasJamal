import os
os.system("cls")

# print("List Iteration")
# l = ["geeks", "for", "geeks"] 
# for i in l:
#     print(i)

# print("\nTuple Iteration")
# t = ("geeks", "for", "geeks") 
# for i in t:
#     print(i)

# print("\nString Iteration") 
# s = "Geeks"
# for i in s :
#     print(i)

def my_function():
    print("Hello from a function")
my_function()

def my_function1(num):
    print(f"Num is  {num}  Square : {num*num}")

x=input("Enter Num : ")
my_function1(int(x))
