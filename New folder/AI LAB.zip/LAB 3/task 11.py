str=[]
while(True):
    a=input()
    if a:
        str.append(a.lower())
    else:
        break
print(str)