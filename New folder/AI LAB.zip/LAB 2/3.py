import os
os.system("cls")

# Python program to illustrate 
# Iterating by index 
list = ["geeks", "for", "geeks"] 
for index in range(len(list)): 
    print (list[index]) 
