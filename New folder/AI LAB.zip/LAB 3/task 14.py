import re
pwd= input("Enter Password : ")
temp = True
while temp:  
    if (len(pwd)<6 or len(pwd)>12):
        break
    elif not re.search("[a-z]",pwd):
        break
    elif not re.search("[0-9]",pwd):
        break
    elif not re.search("[A-Z]",pwd):
        break
    elif not re.search("[$#@]",pwd):
        break
    elif re.search("\s",pwd):
        break
    else:
        print("Valid Password")
        temp=False
        break
if temp:
    print("Not a Valid Password")
