numlist=(1,2,3,4,5,6,7,8,9)
odd=0
even=0
for i in numlist:
    if(i%2==0):
        even = even+1
    else:
        odd=odd+1
print(numlist)
print(f"Number of Odds : {odd}")
print(f"Number of Evens : {even}")