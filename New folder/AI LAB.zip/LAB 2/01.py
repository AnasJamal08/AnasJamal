import os
os.system("cls")

count = 0 
# while count < 3: 
#         count = count + 1 
#         print("Hello Geek") 

while (count == 0): 
    count-=1
    print("Hello Geek") 
