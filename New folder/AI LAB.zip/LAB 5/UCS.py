from queue import PriorityQueue

graph = {
  'A' : [[3,'B'],[2,'C']],
  'B' : [[1,'D'],[3,'F'],[1,'E']],
  'C' : [[1,'F']],
  'D' : [],
  'E' : [[1,'F']],
  'F' : []
}

def ucs(graph, start, goal):
    visited = set()
    queue = PriorityQueue()
    queue.put((0, start))

    while queue:
        cost, node = queue.get()
        print(node)
        if node not in visited:
            visited.add(node)

            if node == goal:
                print(f"Minumum Cost :{cost}")
                return
            for i in graph[node]:
                if i[1] not in visited:
                    total_cost = cost + i[0]
                    queue.put((total_cost, i[1]))

print("Following is the Uniform-Cost Search")
ucs(graph,'A','F')