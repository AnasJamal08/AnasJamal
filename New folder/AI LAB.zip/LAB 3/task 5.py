myStr=input("Enter String : ")
revStr = ""
Strlen = len(myStr)
for count in range(Strlen):
    c = myStr[Strlen - 1 - count]
    reversedString = reversedString + c

print("Original String is:", myStr)
print("Reversed String is:", revStr)